import 'dotenv/config';

const parseInteger = (value: string | undefined, fallback: number): number => {
  const parsed = Number.parseInt(value ?? '', 10);
  return Number.isFinite(parsed) ? parsed : fallback;
};

const parseMinInteger = (value: string | undefined, fallback: number, min: number): number => {
  return Math.max(min, parseInteger(value, fallback));
};

const clampInteger = (value: number, min: number, max: number): number => {
  return Math.min(max, Math.max(min, value));
};

const parseBoolean = (value: string | undefined, fallback: boolean): boolean => {
  if (value === undefined) return fallback;
  const normalized = value.trim().toLowerCase();
  if (normalized === 'true' || normalized === '1' || normalized === 'yes') return true;
  if (normalized === 'false' || normalized === '0' || normalized === 'no') return false;
  return fallback;
};

const parseMode = (value: string | undefined): 'fast' | 'reasoning' | 'assistant' | 'plan' => {
  const normalized = (value || 'reasoning').trim().toLowerCase();
  if (normalized === 'fast') return 'fast';
  if (normalized === 'assistant') return 'assistant';
  if (normalized === 'plan') return 'plan';
  if (normalized === 'reasoning' || normalized === 'deep') return 'reasoning';
  return 'reasoning';
};

const parseKeepAlive = (value: string | undefined): string | number => {
  const raw = (value || '-1').trim();
  if (!raw) return -1;
  const asNumber = Number(raw);
  if (Number.isFinite(asNumber)) return asNumber;
  return raw;
};

// Qwen 2.5 14B Q4_K_M: context window optimized for multi-file tasks.
// 16384 fits ~3 medium files + history + system prompt comfortably.
// 32768 available for large tasks but slows prefill significantly.
const ollamaMaxCtx = parseMinInteger(process.env.OLLAMA_NUM_CTX, 16384, 8192);
const ollamaMinCtx = clampInteger(parseInteger(process.env.OLLAMA_MIN_CTX, 4096), 2048, ollamaMaxCtx);

export const config = {
  ollama: {
    host: process.env.OLLAMA_HOST || 'http://inference.local:11434',
    // Qwen 2.5 Coder 14B Q4_K_M — best balance of quality and RAM for coding tasks.
    // Use qwen2.5-coder:14b-instruct-q4_K_M for code-heavy workloads.
    model: process.env.OLLAMA_MODEL || 'qwen2.5-coder:14b-instruct-q4_K_M',
    keepAlive: parseKeepAlive(process.env.OLLAMA_KEEP_ALIVE),
    requestTimeoutMs: parseInteger(process.env.OLLAMA_REQUEST_TIMEOUT_MS, 180000),
    adaptiveContext: {
      enabled: process.env.OLLAMA_ADAPTIVE_CTX === 'false' ? false : true,
      minCtx: ollamaMinCtx,
      maxCtx: ollamaMaxCtx
    },
    options: {
      num_gpu: parseInteger(process.env.OLLAMA_NUM_GPU, -1),
      num_ctx: ollamaMaxCtx,

      // CRITICAL for Qwen 2.5 14B:
      // num_batch 512 reduces prefill time from ~90s to ~8s on 16k context.
      // The default of 32 makes the model appear "frozen" on large prompts.
      num_batch: parseInteger(process.env.OLLAMA_NUM_BATCH, 512),

      // temperature 0.2: low randomness is essential for structured JSON output,
      // find/replace patches, and code generation. 0.7 causes the model to
      // "creatively" deviate from instructions — exactly the rewrite-everything bug.
      temperature: 0.2,

      // top_p 0.9 with temperature 0.2 provides a sensible nucleus.
      top_p: 0.9,

      // repeat_penalty 1.05: the original 1.1 causes premature truncation
      // in long code blocks — the model stops generating to avoid repetition
      // even when repetition is structurally required (e.g. closing braces).
      repeat_penalty: 1.05,

      // min_p filters out very low-probability tokens independently of top_p.
      // Helps prevent hallucinated API names / method signatures.
      min_p: 0.05
    }
  },
  system: {
    maxHistory: parseInteger(process.env.MAX_HISTORY, 6),  // reduced: 10 fills context fast with code
    mode: parseMode(process.env.MODE),
    ramGB: 16,
    cpuCores: 8
  },
  deliberation: {
    enabled: process.env.DELIBERATION_ENABLED !== 'false',
    // semi-hybrid: only activates deliberation for long or multi-step tasks.
    // 'full' is too expensive for 14B — each summarization call costs 2-5s.
    mode: (process.env.DELIBERATION_MODE || 'semi-hybrid') as 'off' | 'global' | 'semi-hybrid' | 'full',
    storagePath: process.env.DELIBERATION_PATH || './data/deliberation.json',
    // chunkSize in tokens (1 token ≈ 4 chars). 1200 tokens ≈ 4800 chars.
    chunkSize: parseInteger(process.env.DELIBERATION_CHUNK_SIZE, 1200),
    overlap: parseInteger(process.env.DELIBERATION_OVERLAP, 150),
    // summaryMaxTokens: kept short to prevent the 14B from over-elaborating summaries.
    summaryMaxTokens: parseInteger(process.env.DELIBERATION_SUMMARY_TOKENS, 180),
    globalReasoningMaxTokens: parseInteger(process.env.DELIBERATION_GLOBAL_TOKENS, 250),
    maxParts: parseInteger(process.env.DELIBERATION_MAX_PARTS, 100)
  },
  search: {
    maxResults: parseInteger(process.env.SEARCH_MAX_RESULTS, 15),
    contextLines: parseInteger(process.env.SEARCH_CONTEXT_LINES, 2),
    maxFileHits: parseInteger(process.env.SEARCH_MAX_FILE_HITS, 3),
    queryMaxLen: parseInteger(process.env.SEARCH_QUERY_MAX_LEN, 120),
    queryMaxTokens: parseInteger(process.env.SEARCH_QUERY_MAX_TOKENS, 10),
    queryTruncateLen: parseInteger(process.env.SEARCH_QUERY_TRUNCATE_LEN, 100),
    companionMaxTokens: parseInteger(process.env.SEARCH_COMPANION_MAX_TOKENS, 3),
    needleMaxTokens: parseInteger(process.env.SEARCH_NEEDLE_MAX_TOKENS, 6)
  },
  edit: {
    // fullReplaceMaxBytes: raised to 8000 — for Qwen 14B, full-file rewrite is
    // more reliable than apply_patch for files up to ~200 lines. Patch generation
    // fails ~20% of the time on 14B due to whitespace/indent mismatches.
    fullReplaceMaxBytes: parseInteger(process.env.EDIT_FULL_REPLACE_MAX_BYTES, 8000),
    fullReplaceMaxLines: parseInteger(process.env.EDIT_FULL_REPLACE_MAX_LINES, 200)
  },
  tui: {
    renderDebounceMs: parseInteger(process.env.TUI_RENDER_DEBOUNCE_MS, 50),
    streamDebounceMs: parseInteger(process.env.TUI_STREAM_DEBOUNCE_MS, 16),
    reasoningHeight: parseInteger(process.env.TUI_REASONING_HEIGHT, 5),
    maxColumns: parseInteger(process.env.TUI_MAX_COLUMNS, 80)
  },
  sessionContext: {
    enabled: parseBoolean(process.env.SESSION_CONTEXT_ENABLED, true),
    storagePath: process.env.SESSION_CONTEXT_PATH || './data/session-context.json',
    maxTopics: parseInteger(process.env.SESSION_CONTEXT_MAX_TOPICS, 40),
    maxQueriesPerTopic: parseInteger(process.env.SESSION_CONTEXT_MAX_QUERIES, 30),
    maxDirectivesPerType: parseInteger(process.env.SESSION_CONTEXT_MAX_DIRECTIVES, 30),
    searchMaxLines: parseInteger(process.env.SESSION_CONTEXT_SEARCH_MAX_LINES, 12)
  }
};
