import { Intent, Step } from './types.js';
import { OllamaClient, OfflineError, OllamaNotFoundError, OllamaResourceError } from './ollama-client.js';

// Planner — generates a minimal executable step plan.
//
// OPTIMIZATIONS for Qwen 2.5 14B:
//  1. Shallow tasks are capped at 1-2 steps. The 14B tends to generate
//     5 steps regardless of complexity, adding "verify file exists" and
//     "confirm result" steps that only produce extra LLM calls.
//  2. Single-file edits bypass the planner entirely — they are handled as
//     a single step without LLM plan generation.
//  3. dependsOn is now validated: references to non-existent step IDs are
//     dropped instead of being silently carried as dead data.
//  4. Prompt restructured: max steps stated first (14B front-loads attention
//     toward prompt beginning), toolHint simplified.
//  5. Fallback strings changed to English for consistency with prompts.

export class Planner {
  constructor(private llm: OllamaClient) {}

  async createPlan(
    intent: Intent,
    context?: {
      goal?: string;
      workingFiles?: string[];
      files?: Record<string, { exists: boolean; validated: boolean; lastAction: string }>;
    }
  ): Promise<Step[]> {
    // Fast path: single-file shallow tasks don't need a full planning call.
    // This eliminates one LLM call for the most common coding tasks.
    if (this.isSingleFileSTask(intent)) {
      return this.buildSingleFileSteps(intent, context);
    }

    const maxSteps = intent.depth === 'deep' ? 5 : 2;
    const knownFiles = context?.workingFiles?.length
      ? context.workingFiles.join(', ')
      : 'none';

    const prompt = `Create a ${maxSteps}-step max plan. Reply ONLY with JSON, no explanation.

Task: ${intent.query}
Type: ${intent.type}
Files mentioned: ${intent.files.join(', ') || 'none'}
Tracked files: ${knownFiles}
Depth: ${intent.depth}

Rules:
- Maximum ${maxSteps} steps, each atomic and executable
- One file per step for write/edit operations
- Never add "verify existence" or "confirm result" steps — tool results handle that
- If a file must be read before editing, make read step explicit
- toolHint: read_file | write_file | apply_patch | search_code | list_dir | run_code | none

{"steps":[
  {"action":"step description","target":"optional/path.ts","toolHint":"read_file"},
  {"action":"step description","target":"optional/path.ts","toolHint":"apply_patch"}
]}`;

    try {
      const response = await this.llm.generate(prompt);
      const cleaned  = this.extractJson(response);
      const parsed   = JSON.parse(cleaned);

      if (!Array.isArray(parsed.steps) || parsed.steps.length === 0) {
        return this.fallback(intent.query);
      }

      const steps: Step[] = parsed.steps
        .slice(0, maxSteps + 1) // allow one extra for safety, capped in agent
        .map((s: any, i: number) => ({
          id:       `step_${i}`,
          action:   String(s.action || '').trim() || `Step ${i + 1}`,
          status:   'pending' as const,
          target:   typeof s.target   === 'string' && s.target.trim()   ? s.target.trim()   : undefined,
          toolHint: typeof s.toolHint === 'string' && s.toolHint.trim() ? s.toolHint.trim() : undefined,
          // Validate dependsOn: only keep references to steps that exist in this plan
          dependsOn: undefined // resolved below after full steps array is built
        }));

      // Now validate dependsOn with known IDs
      const validIds = new Set(steps.map(s => s.id));
      const rawSteps = parsed.steps.slice(0, steps.length);
      for (let i = 0; i < steps.length; i++) {
        const raw = rawSteps[i];
        if (Array.isArray(raw.dependsOn)) {
          const valid = raw.dependsOn
            .map((d: any) => String(d))
            .filter((d: string) => validIds.has(d) && d !== steps[i].id);
          if (valid.length > 0) steps[i].dependsOn = valid;
        }
      }

      return steps;
    } catch (error) {
      if (
        error instanceof OfflineError ||
        error instanceof OllamaNotFoundError ||
        error instanceof OllamaResourceError
      ) {
        throw error;
      }
      return this.fallback(intent.query);
    }
  }

  // ---------------------------------------------------------------------------
  // Helpers
  // ---------------------------------------------------------------------------

  private isSingleFileSTask(intent: Intent): boolean {
    if (intent.depth === 'deep') return false;
    if (intent.type === 'general' || intent.type === 'search') return false;
    // Single file mentioned → single-file task
    return intent.files.length <= 1;
  }

  private buildSingleFilePlan(intent: Intent, context?: any): Step[] {
    const file = intent.files[0];

    if (intent.type === 'explain' || intent.type === 'debug') {
      return [
        { id: 'step_0', action: `Read ${file || 'the file'} and analyze`, status: 'pending', target: file, toolHint: 'read_file' }
      ];
    }

    if (intent.type === 'code_edit' || intent.type === 'refactor') {
      if (!file) {
        return this.fallback(intent.query);
      }
      const fileKnown = context?.files?.[file];
      if (fileKnown?.exists) {
        return [
          { id: 'step_0', action: `Read ${file}`,   status: 'pending', target: file, toolHint: 'read_file' },
          { id: 'step_1', action: `Edit ${file}: ${intent.query}`, status: 'pending', target: file, toolHint: 'apply_patch' }
        ];
      }
      // File may not exist yet
      return [
        { id: 'step_0', action: `Create ${file}: ${intent.query}`, status: 'pending', target: file, toolHint: 'write_file' }
      ];
    }

    return this.fallback(intent.query);
  }

  // Alias kept for internal callers
  private buildSingleFileSteps(intent: Intent, context?: any): Step[] {
    return this.buildSingleFilePlan(intent, context);
  }

  private fallback(query: string): Step[] {
    return [{
      id: 'step_0',
      action: query || 'Respond to the request',
      status: 'pending' as const
    }];
  }

  private extractJson(raw: string): string {
    const stripped = raw.trim().replace(/```json\s*/gi, '').replace(/```\s*/g, '');
    const start    = stripped.indexOf('{');
    const end      = stripped.lastIndexOf('}');
    if (start !== -1 && end > start) return stripped.slice(start, end + 1);
    return stripped;
  }
}
