import { promises as fs } from 'fs';
import path from 'path';
import { config } from './config.js';

// SessionContextManager — persists per-topic conversation history and directives.
//
// FIX: searchWithRipgrep replaced by searchInMemory.
//
// The original implementation ran ripgrep on the raw JSON store file.
// This caused three problems:
//  1. Token matches hit JSON structural characters (keys, IDs, braces),
//     returning noise lines like `"id":"topic-1234-config"` for a query
//     about "config", polluting the LLM context with irrelevant JSON.
//  2. Results were line numbers in a JSON file — not useful as context.
//  3. ripgrep is not guaranteed to be available on all deployment targets.
//
// The replacement searches in-memory over the parsed store, returning
// matching directive/query strings directly — clean, structured, fast.

export type SessionScope = 'workspace' | 'external' | 'mixed';

export interface SessionTopic {
  id: string;
  title: string;
  scope: SessionScope;
  status: 'active' | 'archived';
  createdAt: number;
  updatedAt: number;
  lastQuery: string;
  queries: string[];
  instructions: string[];
  rules: string[];
  philosophies: string[];
}

interface SessionContextStore {
  version: number;
  updatedAt: number;
  activeTopicId: string | null;
  topics: SessionTopic[];
}

export class SessionContextManager {
  private store: SessionContextStore;

  constructor(private storagePath: string = config.sessionContext.storagePath) {
    this.store = this.emptyStore();
  }

  async load(): Promise<void> {
    if (!config.sessionContext.enabled) return;

    const dir = path.dirname(this.storagePath);
    await fs.mkdir(dir, { recursive: true });

    try {
      const raw    = await fs.readFile(this.storagePath, 'utf-8');
      const parsed = JSON.parse(raw) as SessionContextStore;
      if (parsed?.version === 1 && Array.isArray(parsed.topics)) {
        this.store = parsed;
        return;
      }
    } catch {
      // File missing or corrupt — create fresh
    }

    await this.save();
  }

  getActiveTopic(): SessionTopic | null {
    if (!this.store.activeTopicId) return null;
    return this.store.topics.find(t => t.id === this.store.activeTopicId) ?? null;
  }

  getTopics(): SessionTopic[] {
    return [...this.store.topics].sort((a, b) => b.updatedAt - a.updatedAt);
  }

  async createTopic(title: string, scope: SessionScope, firstQuery: string): Promise<SessionTopic> {
    const now = Date.now();
    const id  = `topic-${now}-${Math.random().toString(36).slice(2, 8)}`;

    const topic: SessionTopic = {
      id,
      title:        this.normalizeTitle(title),
      scope,
      status:       'active',
      createdAt:    now,
      updatedAt:    now,
      lastQuery:    firstQuery,
      queries:      [firstQuery],
      instructions: [],
      rules:        [],
      philosophies: []
    };

    // Archive all currently active topics
    for (const existing of this.store.topics) {
      if (existing.status === 'active') {
        existing.status    = 'archived';
        existing.updatedAt = now;
      }
    }

    this.store.topics.push(topic);
    this.store.activeTopicId = topic.id;
    this.pruneTopics();
    await this.save();
    return topic;
  }

  async updateTopic(topicId: string, update: Partial<SessionTopic>): Promise<SessionTopic | null> {
    const topic = this.store.topics.find(t => t.id === topicId);
    if (!topic) return null;

    const now = Date.now();
    if (typeof update.title === 'string' && update.title.trim()) topic.title = this.normalizeTitle(update.title);
    if (update.scope)  topic.scope  = update.scope;
    if (update.status) topic.status = update.status;
    if (typeof update.lastQuery === 'string' && update.lastQuery.trim()) topic.lastQuery = update.lastQuery;
    if (Array.isArray(update.queries))      topic.queries      = update.queries.slice(0, config.sessionContext.maxQueriesPerTopic);
    if (Array.isArray(update.instructions)) topic.instructions = update.instructions.slice(0, config.sessionContext.maxDirectivesPerType);
    if (Array.isArray(update.rules))        topic.rules        = update.rules.slice(0, config.sessionContext.maxDirectivesPerType);
    if (Array.isArray(update.philosophies)) topic.philosophies = update.philosophies.slice(0, config.sessionContext.maxDirectivesPerType);
    topic.updatedAt = now;

    await this.save();
    return topic;
  }

  async appendQuery(topicId: string, query: string): Promise<SessionTopic | null> {
    const topic = this.store.topics.find(t => t.id === topicId);
    if (!topic) return null;

    const normalized = query.trim();
    if (!normalized) return topic;

    topic.lastQuery = normalized;
    topic.queries.push(normalized);
    topic.queries   = topic.queries.slice(-config.sessionContext.maxQueriesPerTopic);
    topic.updatedAt = Date.now();
    await this.save();
    return topic;
  }

  async appendDirectives(
    topicId: string,
    directives: { instructions?: string[]; rules?: string[]; philosophies?: string[] }
  ): Promise<SessionTopic | null> {
    const topic = this.store.topics.find(t => t.id === topicId);
    if (!topic) return null;

    topic.instructions  = this.mergeDirectiveList(topic.instructions,  directives.instructions);
    topic.rules         = this.mergeDirectiveList(topic.rules,         directives.rules);
    topic.philosophies  = this.mergeDirectiveList(topic.philosophies,  directives.philosophies);
    topic.updatedAt     = Date.now();
    await this.save();
    return topic;
  }

  // FIX: in-memory search over parsed store.
  // Returns matching strings from queries/instructions/rules/philosophies/title
  // filtered by the query tokens. No file I/O, no JSON noise.
  searchInMemory(query: string, maxLines: number = config.sessionContext.searchMaxLines): string[] {
    if (!config.sessionContext.enabled) return [];

    const q = String(query || '').trim();
    if (!q) return [];

    const tokens = this.tokenizeQuery(q);
    if (tokens.length === 0) return [];

    const matches: string[] = [];

    for (const topic of this.store.topics) {
      if (matches.length >= maxLines) break;

      const candidates: string[] = [
        topic.title,
        topic.lastQuery,
        ...topic.queries,
        ...topic.instructions,
        ...topic.rules,
        ...topic.philosophies
      ];

      for (const candidate of candidates) {
        if (matches.length >= maxLines) break;
        if (!candidate || typeof candidate !== 'string') continue;

        const lower = candidate.toLowerCase();
        const hit   = tokens.some(t => lower.includes(t));
        if (hit) matches.push(candidate);
      }
    }

    return matches;
  }

  // Keep old name as alias for callers that used the ripgrep version
  async searchWithRipgrep(query: string, maxLines?: number): Promise<string[]> {
    return this.searchInMemory(query, maxLines);
  }

  // ---------------------------------------------------------------------------
  // Private helpers
  // ---------------------------------------------------------------------------

  private async save(): Promise<void> {
    if (!config.sessionContext.enabled) return;
    this.store.updatedAt = Date.now();
    const tmpPath = `${this.storagePath}.tmp`;
    await fs.writeFile(tmpPath, JSON.stringify(this.store, null, 2), 'utf-8');
    await fs.rename(tmpPath, this.storagePath);
  }

  private pruneTopics(): void {
    if (this.store.topics.length <= config.sessionContext.maxTopics) return;

    const activeId    = this.store.activeTopicId;
    const activeTopic = activeId ? this.store.topics.find(t => t.id === activeId) : null;
    const maxArchived = config.sessionContext.maxTopics - (activeTopic ? 1 : 0);

    const archived = this.store.topics
      .filter(t => t.id !== activeId)
      .sort((a, b) => b.updatedAt - a.updatedAt)
      .slice(0, Math.max(0, maxArchived));

    this.store.topics = activeTopic ? [activeTopic, ...archived] : archived;
  }

  private mergeDirectiveList(current: string[], incoming?: string[]): string[] {
    if (!Array.isArray(incoming) || incoming.length === 0) return current;

    const seen   = new Set<string>();
    const merged = [...current, ...incoming]
      .map(item => String(item || '').trim())
      .filter(Boolean)
      .filter(item => {
        const key = item.toLowerCase();
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      });

    return merged.slice(-config.sessionContext.maxDirectivesPerType);
  }

  private normalizeTitle(title: string): string {
    const clean = String(title || '').replace(/\s+/g, ' ').trim();
    return clean ? clean.slice(0, 120) : 'Untitled topic';
  }

  // Extract meaningful search tokens (≥4 chars, no stopwords)
  private tokenizeQuery(query: string): string[] {
    const stopwords = new Set([
      'the', 'and', 'for', 'with', 'from', 'that', 'this', 'have', 'are', 'was',
      'will', 'can', 'all', 'not', 'what', 'how', 'when', 'where', 'which',
      'como', 'qual', 'que', 'para', 'com', 'uma', 'mais', 'isso', 'este', 'essa'
    ]);

    return query
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .split(/[^a-z0-9]+/)
      .filter(t => t.length >= 3 && !stopwords.has(t))
      .slice(0, 10);
  }

  private emptyStore(): SessionContextStore {
    return {
      version:         1,
      updatedAt:       Date.now(),
      activeTopicId:   null,
      topics:          []
    };
  }
}
