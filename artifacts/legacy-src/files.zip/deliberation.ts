import { promises as fs } from 'fs';
import path from 'path';
import crypto from 'crypto';
import { config } from './config.js';
import { OllamaClient, OfflineError, OllamaNotFoundError, OllamaResourceError } from './ollama-client.js';
import { DeliberationInput, DeliberationPart, DeliberationState } from './types.js';

// DeliberationManager — persistent cross-turn memory via LLM summarization.
//
// FIXES applied:
//  1. tokenize() replaced: now uses char-based splitting consistent with
//     countTokens() (chars/4). The old word-split tokenizer produced a
//     different "token" unit than countTokens, making chunkSize, overlap,
//     and summaryMaxTokens comparisons meaningless.
//  2. lastContextHash: now saved even when all LLM calls fail, preventing
//     infinite retry on the same context in unstable model situations.
//  3. generateSummaryAndReasoning prompt: shortened and restructured for
//     Qwen 2.5 14B — the original prompt caused the model to produce
//     prose JSON descriptions instead of valid JSON objects.

export class DeliberationManager {
  private state: DeliberationState;
  private lastContextHash: string | null = null;
  private lastUpdateFromModel: boolean = false;

  constructor(private llm: OllamaClient) {
    this.state = this.createInitialState();
  }

  async load(): Promise<void> {
    const filePath = config.deliberation.storagePath;
    try {
      const raw = await fs.readFile(filePath, 'utf-8');
      const parsed = JSON.parse(raw) as DeliberationState;
      if (parsed && parsed.schema === 'deliberation/v1') {
        this.state = parsed;
      }
    } catch {
      await this.save();
    }
  }

  async save(): Promise<void> {
    const filePath = config.deliberation.storagePath;
    const dir = path.dirname(filePath);
    await fs.mkdir(dir, { recursive: true });
    const tmpPath = `${filePath}.tmp`;
    await fs.writeFile(tmpPath, JSON.stringify(this.state, null, 2), 'utf-8');
    await fs.rename(tmpPath, filePath);
  }

  getState(): DeliberationState {
    return this.state;
  }

  getGlobalReasoning(): string {
    return this.state.globalReasoning.text;
  }

  wasUpdatedByModel(): boolean {
    return this.lastUpdateFromModel;
  }

  getRecentSummaries(maxParts: number = 3): string[] {
    return this.state.parts.slice(-maxParts).map(p => p.summary);
  }

  async processContext(input: DeliberationInput): Promise<DeliberationState> {
    if (!config.deliberation.enabled) return this.state;

    const text = input.text.trim();
    if (!text) return this.state;

    this.lastUpdateFromModel = false;
    const hash = crypto.createHash('sha1').update(text).digest('hex');

    if (hash === this.lastContextHash) return this.state;

    // FIX: mark hash immediately so that repeated failures on the same
    // context don't re-enter this expensive path on every subsequent call.
    // lastUpdateFromModel remains false if no LLM call succeeds.
    this.lastContextHash = hash;

    const { chunkSize, overlap, maxParts } = this.state.tokenBudget;
    // chunkSize and overlap are in "tokens" (1 token = 4 chars).
    // Convert to character offsets for consistent slicing.
    const charChunkSize = chunkSize * 4;
    const charOverlap   = overlap * 4;

    const baseCharOffset = this.state.parts.length > 0
      ? (this.state.parts[this.state.parts.length - 1].endToken * 4) + 1
      : 0;

    for (let start = 0; start < text.length; start += charChunkSize - charOverlap) {
      const end       = Math.min(start + charChunkSize, text.length);
      const chunkText = text.slice(start, end);

      const result = await this.generateSummaryAndReasoning(chunkText, this.state.globalReasoning.text);
      if (!result) continue;

      const { summary, reasoning } = result;
      const summaryTokens = this.countTokens(summary);

      const prevIndex = this.state.parts.length > 0
        ? this.state.parts[this.state.parts.length - 1].index
        : 0;

      const part: DeliberationPart = {
        index: prevIndex + 1,
        source: input.source,
        sourceId: input.sourceId,
        // Store offsets in token units (chars/4) for consistent budget tracking
        startToken: Math.floor((baseCharOffset + start) / 4),
        endToken:   Math.floor((baseCharOffset + end - 1) / 4),
        overlapFromPrev: start === 0 ? 0 : overlap,
        rawChars: chunkText.length,
        summary,
        summaryTokens,
        summaryAt: new Date().toISOString()
      };

      this.state.parts.push(part);
      if (this.state.parts.length > maxParts) {
        this.state.parts.shift();
      }

      this.state.globalReasoning.text        = reasoning || summary;
      this.state.globalReasoning.lastPartIndex  = part.index;
      this.state.globalReasoning.lastUpdateAt   = new Date().toISOString();
      this.state.updatedAt                      = new Date().toISOString();
      this.lastUpdateFromModel                  = true;
    }

    await this.save();
    return this.state;
  }

  private createInitialState(): DeliberationState {
    const now = new Date().toISOString();
    return {
      version: 1,
      schema: 'deliberation/v1',
      model: config.ollama.model,
      tokenBudget: {
        chunkSize: config.deliberation.chunkSize,
        overlap: config.deliberation.overlap,
        summaryMaxTokens: config.deliberation.summaryMaxTokens,
        globalReasoningMaxTokens: config.deliberation.globalReasoningMaxTokens,
        maxParts: config.deliberation.maxParts
      },
      createdAt: now,
      updatedAt: now,
      globalReasoning: {
        text: '',
        lastPartIndex: 0,
        lastUpdateAt: now
      },
      parts: []
    };
  }

  // FIX: countTokens is now the single canonical token estimator.
  // 1 token ≈ 4 chars (standard sub-word approximation).
  private countTokens(text: string): number {
    return Math.ceil(text.length / 4);
  }

  private async generateSummaryAndReasoning(
    text: string,
    currentReasoning: string
  ): Promise<{ summary: string; reasoning: string } | null> {
    const maxSummaryChars   = this.state.tokenBudget.summaryMaxTokens * 4;
    const maxReasoningChars = this.state.tokenBudget.globalReasoningMaxTokens * 4;

    // Optimized prompt for Qwen 2.5 14B:
    // - Shorter preamble (14B follows short instructions better than long ones)
    // - Strict JSON-only instruction placed at the end (Qwen attends to end of prompt strongly)
    // - Explicit character limits instead of token limits (model understands chars better)
    const prompt = `Summarize the chunk below and update the global reasoning.

Global reasoning so far:
${this.truncateText(currentReasoning, maxReasoningChars) || '(none)'}

Chunk:
${text.slice(0, 3200)}

Rules:
- summary: max ${maxSummaryChars} chars, factual only
- reasoning: max ${maxReasoningChars} chars, updated synthesis
- Do not invent facts; if conflict exists, newer chunk takes precedence
- Output ONLY a JSON object, no markdown, no explanation

{"summary":"...","reasoning":"..."}`;

    try {
      const response = await this.llm.generate(prompt);
      const cleaned  = this.extractJson(response);
      const parsed   = JSON.parse(cleaned);

      if (typeof parsed?.summary !== 'string' || typeof parsed?.reasoning !== 'string') {
        return null;
      }

      return {
        summary:   this.truncateText(parsed.summary.trim(),   maxSummaryChars),
        reasoning: this.truncateText(parsed.reasoning.trim(), maxReasoningChars)
      };
    } catch (error) {
      if (
        error instanceof OfflineError ||
        error instanceof OllamaNotFoundError ||
        error instanceof OllamaResourceError
      ) {
        throw error;
      }
      return null;
    }
  }

  // Robust JSON extraction: handles cases where the 14B wraps output in
  // ```json ... ``` or adds trailing prose after the closing brace.
  private extractJson(raw: string): string {
    const stripped = raw.trim().replace(/```json\s*/gi, '').replace(/```\s*/g, '');
    // Find first { ... } block
    const start = stripped.indexOf('{');
    const end   = stripped.lastIndexOf('}');
    if (start !== -1 && end > start) {
      return stripped.slice(start, end + 1);
    }
    return stripped;
  }

  private truncateText(text: string, maxChars: number): string {
    if (!text) return '';
    if (text.length <= maxChars) return text;
    return text.slice(0, maxChars);
  }
}
